import DashboardLayouts from "../../layouts/DashboardLayouts";

export default function Home() {
  return (
    <>
      <DashboardLayouts>
        <div></div>
      </DashboardLayouts>
    </>
  );
}
