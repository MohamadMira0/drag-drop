import EditModeLayouts from "../../layouts/EditModeLayouts";
import { useEffect, useState } from "react";
import { Layout, Responsive, WidthProvider } from "react-grid-layout";
import { IDummyData } from "../../interfaces";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";

const ResponsiveGridLayout = WidthProvider(Responsive);

export default function EditMode() {
  const [components, setComponents] = useState<IDummyData[]>([]);
  const [layout, setLayout] = useState<Layout[]>([]);

  // استرجاع البيانات من localStorage عند بدء الصفحة
  useEffect(() => {
    const savedComponents = localStorage.getItem("gridComponents");
    const savedLayout = localStorage.getItem("gridLayout");
    if (savedComponents && savedLayout) {
      setComponents(JSON.parse(savedComponents));
      setLayout(JSON.parse(savedLayout));
    }
  }, []);

  // حفظ التغييرات تلقائيًا
  useEffect(() => {
    localStorage.setItem("gridComponents", JSON.stringify(components));
    localStorage.setItem("gridLayout", JSON.stringify(layout));
  }, [components, layout]);

  const handleDrop = (layout: Layout[], layoutItem: Layout) => {
    const widget = localStorage.getItem("dragging-widget");
    if (!widget) return;

    const data: IDummyData = JSON.parse(widget);

    setComponents((prev) => [
      ...prev,
      {
        ...data,
        position: { x: layoutItem.x, y: layoutItem.y },
        size: { width: layoutItem.w * 100, height: layoutItem.h * 100 },
      },
    ]);

    setLayout((prev) => [...prev, layoutItem]);
  };

  return (
    <EditModeLayouts>
      <ResponsiveGridLayout
        className="layout"
        layouts={{ lg: layout }}
        breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480 }}
        cols={{ lg: 12, md: 10, sm: 6, xs: 4 }}
        rowHeight={100}
        preventCollision={true}
        isDroppable={true}
        onDrop={handleDrop}
        onLayoutChange={(currentLayout) => setLayout(currentLayout)}
      >
        {components.map((item, index) => (
          <div key={index} className="bg-white border p-2 shadow rounded">
            <img
              className="w-full h-24 object-cover mb-2"
              src={item.img}
              alt="Widget"
            />
            <h3 className="font-bold">{item.title}</h3>
            <p className="text-sm text-gray-600">{item.description}</p>
          </div>
        ))}
      </ResponsiveGridLayout>
    </EditModeLayouts>
  );
}
