import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import {
  WidthProvider,
  Responsive,
  Layout,
  Layouts,
  ResponsiveProps,
} from "react-grid-layout";
import Navbar from "../components/dashboard/Navbar";
import RightSidebar from "../components/dashboard/RightSidebar";
import LeftSidebar from "../components/dashboard/LeftSidebar";
import { useSidebar } from "../hooks/useSidebar";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";

const ResponsiveGridLayout = WidthProvider(Responsive);

interface WidgetComponent {
  id: string;
  title: string;
  description: string;
  img: string;
  type: number;
  typeTitle: string;
}

export default function EditModeLayouts({ children }: { children: ReactNode }) {
  const { isOpen } = useSidebar();

  const [gridItems, setGridItems] = useState<{
    layout: Layout[];
    components: WidgetComponent[];
  }>({
    layout: [],
    components: [],
  });

  useEffect(() => {
    const saved = localStorage.getItem("grid-items");
    if (saved) {
      setGridItems(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("grid-items", JSON.stringify(gridItems));
  }, [gridItems]);

  const handleWidgetDragStart = (component: WidgetComponent) => {
    localStorage.setItem("dragging-widget", JSON.stringify(component));
  };

  const handleDrop = (_layout: Layout[], layoutItem: Layout) => {
    const data = localStorage.getItem("dragging-widget");
    if (!data) return;
    const component: WidgetComponent = JSON.parse(data);

    const newComponent = { ...component, id: `${component.id}-${Date.now()}` }; // لتفادي التكرار

    setGridItems((prev) => ({
      layout: [...prev.layout, { ...layoutItem, i: newComponent.id }],
      components: [...prev.components, newComponent],
    }));
  };

  const handleLayoutChange = (newLayout: Layout[]) => {
    setGridItems((prev) => ({ ...prev, layout: newLayout }));
  };

  return (
    <>
      <Navbar />
      <LeftSidebar />
      <RightSidebar onWidgetDragStart={handleWidgetDragStart} />
      <div className={`mt-16 duration-300 ${isOpen ? "ms-44" : "ms-20"} p-4`}>
        <ResponsiveGridLayout
          className="layout"
          layouts={{ lg: gridItems.layout } as Layouts}
          breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480 }}
          cols={{ lg: 12, md: 10, sm: 6, xs: 4 }}
          rowHeight={100}
          preventCollision={true}
          isDroppable={true}
          onDrop={handleDrop}
          onLayoutChange={handleLayoutChange}
        >
          {gridItems.components.map((component, index) => {
            const layoutItem = gridItems.layout.find(
              (l) => l.i === component.id
            );
            if (!layoutItem) return null;

            return (
              <div
                key={component.id}
                data-grid={layoutItem}
                className="bg-white border border-gray-300 p-2 rounded shadow"
              >
                <img
                  src={component.img}
                  alt={component.title}
                  className="w-full"
                />
                <h3 className="font-bold text-secondery">{component.title}</h3>
                <p className="text-secondery2 text-sm">
                  {component.description}
                </p>
              </div>
            );
          })}
        </ResponsiveGridLayout>
        {children}
      </div>
    </>
  );
}
