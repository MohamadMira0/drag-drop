export default function Navbar() {
  return (
    <>
      <div
        className={`bg-layout fixed left-0 top-0 w-screen h-14 flex items-center shadow z-10`}
      ></div>
    </>
  );
}
