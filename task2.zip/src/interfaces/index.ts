export interface IDummyData {
  id: string;
  title: string;
  description: string;
  img: string;
  typeTitle?: string;
  type?: number;
  position?: { x: number; y: number };
  size?: { width: number; height: number };
}
